﻿namespace InjecaoDependencia.Model.ViewModel
{
    public class InjecaoDependenciaViewModel
    {
        public Guid Transiente { get; set; }
        public Guid Transiente2 { get; set; }
        public Guid Scoped { get; set; }
        public Guid Scoped2 { get; set; }
        public Guid Singleton { get; set; }
        public Guid Singleton2 { get; set; }
    }
}
