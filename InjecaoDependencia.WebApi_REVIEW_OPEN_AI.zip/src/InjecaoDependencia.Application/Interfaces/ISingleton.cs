﻿namespace InjecaoDependencia.Application.Interfaces
{
    public interface ISingleton
    {
        Guid ObterSingleton();
    }
}
