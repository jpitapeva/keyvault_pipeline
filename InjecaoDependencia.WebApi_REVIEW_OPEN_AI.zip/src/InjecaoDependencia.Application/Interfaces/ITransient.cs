﻿namespace InjecaoDependencia.Application.Interfaces
{
    public interface ITransient
    {
        Guid ObterTransient();
    }
}
