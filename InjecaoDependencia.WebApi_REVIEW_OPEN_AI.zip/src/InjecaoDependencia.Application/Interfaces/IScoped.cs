﻿namespace InjecaoDependencia.Application.Interfaces
{
    public interface IScoped
    {
        Guid ObterScoped();
    }
}
